export interface PlantIdentificationResult {
  name: string;
  scientificName: string;
  confidence: number;
  description: string;
  imageUri: string;
  capturedImageUri?: string; // Original captured image
  similarImages: string[];
  family: string;
  commonNames: string[];
  location: 'Indoor' | 'Outdoor';
  details?: {
    edibleParts?: string[];
    propagationMethods?: string[];
    watering?: {
      min: number;
      max: number;
    };
    bestWatering?: string;
    bestLightCondition?: string;
    bestSoilType?: string;
    commonUses?: string;
    toxicity?: string;
    culturalSignificance?: string;
  };
  healthAssessment?: {
    isHealthy: boolean;
    confidence: number;
    diseases?: Array<{
      name: string;
      probability: number;
      description?: string;
      treatment?: {
        biological?: string[];
        chemical?: string[];
        prevention: string[];
      };
    }>;
  };
  careInstructions?: {
    light?: string;
    water?: string;
    soil?: string;
    temperature?: string;
    humidity?: string;
  };
}