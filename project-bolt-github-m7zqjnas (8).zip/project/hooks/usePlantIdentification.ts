import { useState } from 'react';
import { Platform } from 'react-native';
import { useAuth } from '@/contexts/AuthContext';
import { usePlants } from './usePlants';
import { useOfflineSync } from './useOfflineSync';

interface PlantIdentificationResult {
  name: string;
  scientificName: string;
  confidence: number;
  description: string;
  imageUri: string;
  capturedImageUri?: string;
  similarImages: string[];
  family: string;
  commonNames: string[];
  location: 'Indoor' | 'Outdoor';
  details?: {
    edibleParts?: string[];
    propagationMethods?: string[];
    watering?: {
      min: number;
      max: number;
    };
    bestWatering?: string;
    bestLightCondition?: string;
    bestSoilType?: string;
    commonUses?: string;
    toxicity?: string;
    culturalSignificance?: string;
  };
  healthAssessment?: {
    isHealthy: boolean;
    confidence: number;
    diseases?: Array<{
      name: string;
      probability: number;
      description?: string;
      treatment?: {
        biological?: string[];
        chemical?: string[];
        prevention: string[];
      };
    }>;
  };
  careInstructions?: {
    light?: string;
    water?: string;
    soil?: string;
    temperature?: string;
    humidity?: string;
  };
}

// Common indoor plant families
const INDOOR_PLANT_FAMILIES = [
  'araceae',        // Philodendrons, Pothos, Peace Lilies
  'marantaceae',    // Prayer Plants
  'asparagaceae',   // Snake Plants
  'arecaceae',      // Indoor Palms
  'moraceae',       // Ficus
  'polypodiaceae',  // Ferns
  'orchidaceae',    // Orchids
  'begoniaceae',    // Begonias
  'gesneriaceae',   // African Violets
  'acanthaceae',    // Persian Shield
];

// Light requirement keywords that suggest indoor plants
const INDOOR_LIGHT_KEYWORDS = [
  'low light',
  'shade',
  'indirect light',
  'filtered light',
  'partial shade',
];

export function usePlantIdentification() {
  const [identifying, setIdentifying] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [results, setResults] = useState<PlantIdentificationResult[]>([]);
  const { addPlant } = usePlants();
  const { session } = useAuth();
  const { isOnline } = useOfflineSync();

  const checkConnectivity = () => {
    if (!isOnline) {
      throw new Error('No internet connection. Please check your connection and try again.');
    }
  };

  const determineLocation = (
    family: string,
    description: string,
    commonNames: string[]
  ): 'Indoor' | 'Outdoor' => {
    const familyLower = family.toLowerCase();
    if (INDOOR_PLANT_FAMILIES.some(f => familyLower.includes(f))) {
      return 'Indoor';
    }

    // Check description and common names for indoor indicators
    const fullText = `${description} ${commonNames.join(' ')}`.toLowerCase();
    if (INDOOR_LIGHT_KEYWORDS.some(keyword => fullText.includes(keyword))) {
      return 'Indoor';
    }

    const isCommonIndoorPlant = commonNames.some(name => 
      name.toLowerCase().includes('houseplant') ||
      name.toLowerCase().includes('indoor')
    );

    if (isCommonIndoorPlant) {
      return 'Indoor';
    }

    return 'Outdoor';
  };

  const identifyPlant = async (imageUri: string): Promise<PlantIdentificationResult[]> => {
    try {
      setIdentifying(true);
      setError(null);
      checkConnectivity();

      const response = await fetch(imageUri);
      const blob = await response.blob();
      const base64Image = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64 = reader.result as string;
          resolve(base64.split(',')[1]);
        };
        reader.onerror = reject;
        reader.readAsDataURL(blob);
      });

      const detailKeys = [
  'common_names', 'url', 'description',
  'taxonomy', 'rank',
  'gbif_id', 'inaturalist_id',
  'image', 'images',
  'edible_parts', 'propagation_methods',
  'watering', 'best_watering',
  'best_light_condition',
  'best_soil_type',
  'common_uses', 'toxicity',
  'cultural_significance'
].join(',');

       const url = `https://plant.id/api/v3/identification?details=${encodeURIComponent(detailKeys)}&language=en`;
      const identificationResult = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Api-Key': process.env.EXPO_PUBLIC_PLANT_ID_KEY!
        },
        body: JSON.stringify({
          images: [base64Image],
          similar_images: true,
          health: 'all',
        })
      });

if (!identificationResult.ok) {
  const text = await identificationResult.text();
  console.error('Plant.ID returned non‑JSON error:', identificationResult.status, text);
  throw new Error(`Plant.ID error ${identificationResult.status}: ${text}`);
}

      const data = await identificationResult.json();

      console.log(data, 'found data response')

      if (!data.result?.classification?.suggestions?.length) {
        throw new Error('No plant matches found');
      }

      const plantResults = data.result.classification.suggestions
        .slice(0, 5)
        .map(suggestion => {
          const details = suggestion.details || {};
          const location = determineLocation(
            details.taxonomy?.family || '',
            details.description || '',
            details.common_names || []
          );
          
          const healthAssessment = data.result.health ? {
            isHealthy: data.result.health.is_healthy.binary,
            confidence: data.result.health.is_healthy.probability,
            diseases: data.result.health.diseases?.suggestions?.map(disease => ({
              name: disease.name,
              probability: disease.probability,
              description: disease.details?.description,
              treatment: disease.details?.treatment
            }))
          } : undefined;

          return {
            name: suggestion.name,
            scientificName: details.name_authority || suggestion.name,
            confidence: suggestion.probability,
            description: details.description || 'No description available',
            imageUri: suggestion.similar_images?.[0]?.url || imageUri,
            capturedImageUri: imageUri,
            similarImages: (suggestion.similar_images || [])
              .map(img => img.url)
              .filter(url => url && url.startsWith('https://')),
            family: details.taxonomy?.family || 'Unknown family',
            commonNames: details.common_names || [suggestion.name],
            location,
            details: {
              edibleParts: details.edible_parts,
              propagationMethods: details.propagation_methods,
              watering: details.watering,
              bestWatering: details.best_watering,
              bestLightCondition: details.best_light_condition,
              bestSoilType: details.best_soil_type,
              commonUses: details.common_uses,
              toxicity: details.toxicity,
              culturalSignificance: details.cultural_significance
            },
            healthAssessment,
            careInstructions: {
              light: details.best_light_condition,
              water: details.best_watering,
              soil: details.best_soil_type,
              temperature: location === 'Indoor' ? '65-80°F (18-27°C)' : '60-85°F (15-29°C)',
              humidity: location === 'Indoor' ? 'Moderate to high' : 'Varies by climate'
            }
          };
        });

      setResults(plantResults);
      return plantResults;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to identify plant';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setIdentifying(false);
    }
  };

  const saveIdentifiedPlant = async (identificationResult: PlantIdentificationResult) => {
    try {
      if (!identificationResult?.name) {
        throw new Error('Invalid plant identification result');
      }

      const imageToUse = identificationResult.capturedImageUri;
      if (!imageToUse) {
        throw new Error('No captured image available');
      }

      console.log('Saving plant with location:', identificationResult.location);

      const healthStatus = identificationResult.healthAssessment 
        ? (identificationResult.healthAssessment.isHealthy ? 'Healthy' : 'Needs Attention')
        : 'Not checked';

      const newPlant = await addPlant({
        name: identificationResult.scientificName || identificationResult.name,
        nickname: identificationResult.name,
        image_url: imageToUse,
        location: identificationResult.location,
        health_status: healthStatus,
        notes: identificationResult.description,
        is_favorite: false
      });

      return newPlant;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to save plant';
      throw new Error(message);
    }
  };

  return {
    identifying,
    error,
    results,
    identifyPlant,
    saveIdentifiedPlant
  };
}